
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// netlify/functions/data.mts
import { getDatabase } from "@netlify/database";

// netlify/functions/_shared/auth.mts
import { getUser } from "@netlify/identity";
import { jwtVerify } from "jose";

// db/index.ts
import { drizzle } from "drizzle-orm/netlify-db";

// db/schema.ts
var schema_exports = {};
__export(schema_exports, {
  appointmentReminders: () => appointmentReminders,
  appointments: () => appointments,
  auditLogs: () => auditLogs,
  backups: () => backups,
  clinics: () => clinics,
  invoices: () => invoices,
  notifications: () => notifications,
  patients: () => patients,
  payments: () => payments,
  procedures: () => procedures,
  providerAvailability: () => providerAvailability,
  providers: () => providers,
  subscriptionInvoices: () => subscriptionInvoices,
  subscriptions: () => subscriptions,
  userClinics: () => userClinics,
  users: () => users,
  visitProcedures: () => visitProcedures,
  visits: () => visits
});
import {
  bigint,
  boolean,
  check,
  date,
  index,
  integer,
  jsonb,
  numeric,
  pgTable,
  text,
  time,
  timestamp,
  unique,
  uuid
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
var timestamps = {
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow()
};
var users = pgTable("users", {
  id: uuid("id").primaryKey(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
});
var clinics = pgTable("clinics", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  address: text("address"),
  phone: text("phone"),
  email: text("email"),
  plan: text("plan").notNull().default("starter"),
  subscriptionStatus: text("subscription_status").notNull().default("inactive"),
  currencyCode: text("currency_code").default("PHP"),
  currencySymbol: text("currency_symbol").default("\u20B1"),
  ...timestamps
});
var userClinics = pgTable("user_clinics", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  role: text("role").notNull().default("staff"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (table) => [
  unique("user_clinics_user_id_clinic_id_key").on(table.userId, table.clinicId),
  check("user_clinics_role_check", sql`${table.role} in ('owner', 'admin', 'staff')`),
  index("idx_user_clinics_user_id").on(table.userId),
  index("idx_user_clinics_clinic_id").on(table.clinicId)
]);
var patients = pgTable("patients", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email"),
  phone: text("phone"),
  dateOfBirth: date("date_of_birth"),
  gender: text("gender"),
  address: text("address"),
  medicalNotes: text("medical_notes"),
  ...timestamps
}, (table) => [
  check("patients_gender_check", sql`${table.gender} is null or ${table.gender} in ('male', 'female', 'other')`),
  index("idx_patients_clinic_id").on(table.clinicId),
  index("idx_patients_name").on(table.lastName, table.firstName)
]);
var providers = pgTable("providers", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
  name: text("name").notNull(),
  specialization: text("specialization"),
  ...timestamps
}, (table) => [
  index("idx_providers_clinic_id").on(table.clinicId),
  index("idx_providers_user_id").on(table.userId)
]);
var providerAvailability = pgTable("provider_availability", {
  id: uuid("id").primaryKey().defaultRandom(),
  providerId: uuid("provider_id").notNull().references(() => providers.id, { onDelete: "cascade" }),
  dayOfWeek: integer("day_of_week").notNull(),
  startTime: time("start_time").notNull(),
  endTime: time("end_time").notNull(),
  ...timestamps
}, (table) => [
  check("provider_availability_day_check", sql`${table.dayOfWeek} between 0 and 6`),
  unique("idx_provider_day_time").on(table.providerId, table.dayOfWeek, table.startTime),
  index("idx_provider_availability_provider_id").on(table.providerId)
]);
var appointments = pgTable("appointments", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  patientId: uuid("patient_id").notNull().references(() => patients.id, { onDelete: "cascade" }),
  providerId: uuid("provider_id").references(() => providers.id, { onDelete: "set null" }),
  startTime: timestamp("start_time", { withTimezone: true }).notNull(),
  endTime: timestamp("end_time", { withTimezone: true }).notNull(),
  status: text("status").default("scheduled"),
  notes: text("notes"),
  ...timestamps
}, (table) => [
  check("appointments_status_check", sql`${table.status} in ('scheduled', 'confirmed', 'completed', 'cancelled')`),
  index("idx_appointments_clinic").on(table.clinicId),
  index("idx_appointments_clinic_id").on(table.clinicId),
  index("idx_appointments_patient_id").on(table.patientId),
  index("idx_appointments_provider_id").on(table.providerId),
  index("idx_provider_time").on(table.providerId, table.startTime, table.endTime),
  index("idx_appointments_provider_day").on(table.providerId, table.startTime),
  index("idx_appointments_clinic_start_time").on(table.clinicId, table.startTime)
]);
var procedures = pgTable("procedures", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  description: text("description").default(""),
  baseCost: numeric("base_cost", { precision: 10, scale: 2 }).notNull().default("0"),
  ...timestamps
}, (table) => [index("idx_procedures_clinic_id").on(table.clinicId)]);
var visits = pgTable("visits", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  appointmentId: uuid("appointment_id").references(() => appointments.id, { onDelete: "set null" }),
  patientId: uuid("patient_id").notNull().references(() => patients.id, { onDelete: "cascade" }),
  providerId: uuid("provider_id").notNull().references(() => providers.id, { onDelete: "restrict" }),
  status: text("status").notNull().default("scheduled"),
  chiefComplaint: text("chief_complaint").default(""),
  diagnosis: text("diagnosis").default(""),
  notes: text("notes").default(""),
  visitDate: timestamp("visit_date", { withTimezone: true }).notNull().defaultNow(),
  ...timestamps
}, (table) => [
  check("valid_visit_status", sql`${table.status} in ('scheduled', 'in_progress', 'completed', 'cancelled')`),
  unique("unique_visit_per_appointment").on(table.appointmentId),
  index("idx_visits_clinic_id").on(table.clinicId),
  index("idx_visits_patient_id").on(table.patientId),
  index("idx_visits_appointment_id").on(table.appointmentId),
  index("idx_visits_clinic_date").on(table.clinicId, table.visitDate.desc())
]);
var visitProcedures = pgTable("visit_procedures", {
  id: uuid("id").primaryKey().defaultRandom(),
  visitId: uuid("visit_id").notNull().references(() => visits.id, { onDelete: "cascade" }),
  procedureId: uuid("procedure_id").notNull().references(() => procedures.id, { onDelete: "restrict" }),
  quantity: integer("quantity").notNull().default(1),
  price: numeric("price", { precision: 10, scale: 2 }).notNull().default("0"),
  notes: text("notes").default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (table) => [
  check("positive_quantity", sql`${table.quantity} > 0`),
  check("non_negative_price", sql`${table.price} >= 0`),
  unique("unique_visit_procedure").on(table.visitId, table.procedureId),
  index("idx_visit_procedures_visit_id").on(table.visitId),
  index("idx_visit_procedures_procedure_id").on(table.procedureId)
]);
var invoices = pgTable("invoices", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  visitId: uuid("visit_id").notNull().references(() => visits.id, { onDelete: "cascade" }),
  status: text("status").notNull().default("unpaid"),
  totalAmount: numeric("total_amount", { precision: 10, scale: 2 }).notNull().default("0"),
  amountPaid: numeric("amount_paid", { precision: 10, scale: 2 }).notNull().default("0"),
  ...timestamps
}, (table) => [
  check("invoices_status_check", sql`${table.status} in ('unpaid', 'partial', 'paid', 'void')`),
  unique("invoices_visit_unique").on(table.visitId),
  index("idx_invoices_clinic_id").on(table.clinicId),
  index("idx_invoices_clinic").on(table.clinicId),
  index("idx_invoices_visit").on(table.visitId),
  index("idx_invoices_status").on(table.status)
]);
var payments = pgTable("payments", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  invoiceId: uuid("invoice_id").notNull().references(() => invoices.id, { onDelete: "cascade" }),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  method: text("method").notNull(),
  notes: text("notes").default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (table) => [
  check("payments_method_check", sql`${table.method} in ('cash', 'card', 'bank_transfer', 'other')`),
  index("idx_payments_clinic_id").on(table.clinicId),
  index("idx_payments_invoice_id").on(table.invoiceId),
  index("idx_payments_invoice").on(table.invoiceId)
]);
var auditLogs = pgTable("audit_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  action: text("action").notNull(),
  entityType: text("entity_type").notNull(),
  entityId: uuid("entity_id").notNull(),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (table) => [
  index("idx_audit_logs_clinic_id").on(table.clinicId),
  index("idx_audit_logs_created_at").on(table.createdAt.desc()),
  index("idx_audit_logs_clinic_created").on(table.clinicId, table.createdAt.desc()),
  index("idx_audit_logs_entity").on(table.entityType, table.entityId),
  index("idx_audit_logs_user_id").on(table.userId)
]);
var subscriptions = pgTable("subscriptions", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  stripeCustomerId: text("stripe_customer_id").notNull().unique(),
  stripeSubscriptionId: text("stripe_subscription_id").unique(),
  plan: text("plan").notNull().default("starter"),
  status: text("status").notNull().default("incomplete"),
  currentPeriodEnd: timestamp("current_period_end", { withTimezone: true }),
  ...timestamps
}, (table) => [
  index("idx_subscriptions_clinic_id").on(table.clinicId),
  index("idx_subscriptions_stripe_customer_id").on(table.stripeCustomerId),
  index("idx_subscriptions_stripe_subscription_id").on(table.stripeSubscriptionId)
]);
var notifications = pgTable("notifications", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  type: text("type").notNull(),
  message: text("message").notNull(),
  read: boolean("read").notNull().default(false),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (table) => [
  index("idx_notifications_user_id").on(table.userId),
  index("idx_notifications_clinic_id").on(table.clinicId),
  index("idx_notifications_read").on(table.read),
  index("idx_notifications_created_at").on(table.createdAt.desc()),
  index("idx_notifications_user_read").on(table.userId, table.read)
]);
var backups = pgTable("backups", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").references(() => clinics.id, { onDelete: "cascade" }),
  backupTime: timestamp("backup_time", { withTimezone: true }).notNull().defaultNow(),
  backupStatus: text("backup_status").notNull().default("pending"),
  storageUrl: text("storage_url"),
  backupSize: bigint("backup_size", { mode: "number" }).default(0),
  backupType: text("backup_type").notNull().default("full"),
  errorMessage: text("error_message"),
  ...timestamps
}, (table) => [
  index("idx_backups_clinic_id").on(table.clinicId),
  index("idx_backups_backup_time").on(table.backupTime.desc()),
  index("idx_backups_status").on(table.backupStatus)
]);
var appointmentReminders = pgTable("appointment_reminders", {
  id: uuid("id").primaryKey().defaultRandom(),
  appointmentId: uuid("appointment_id").notNull().references(() => appointments.id, { onDelete: "cascade" }),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  reminderTime: timestamp("reminder_time", { withTimezone: true }).notNull(),
  sent: boolean("sent").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow()
}, (table) => [
  index("idx_appointment_reminders_pending").on(table.clinicId, table.sent, table.reminderTime).where(sql`${table.sent} = false`),
  index("idx_appointment_reminders_appointment_id").on(table.appointmentId)
]);
var subscriptionInvoices = pgTable("subscription_invoices", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").references(() => clinics.id, { onDelete: "cascade" }),
  stripeInvoiceId: text("stripe_invoice_id").notNull().unique(),
  stripeSubscriptionId: text("stripe_subscription_id"),
  amountDue: numeric("amount_due", { precision: 10, scale: 2 }).notNull().default("0"),
  amountPaid: numeric("amount_paid", { precision: 10, scale: 2 }).notNull().default("0"),
  currency: text("currency").notNull().default("usd"),
  status: text("status").notNull().default("open"),
  invoicePdfUrl: text("invoice_pdf_url"),
  paidAt: timestamp("paid_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (table) => [
  index("idx_subscription_invoices_clinic_id").on(table.clinicId),
  index("idx_subscription_invoices_stripe_invoice_id").on(table.stripeInvoiceId)
]);

// db/index.ts
var db = drizzle({ schema: schema_exports });

// netlify/functions/_shared/auth.mts
var AuthenticationError = class extends Error {
};
async function getCurrentUser(request) {
  const identityUser = await getUser();
  let authenticatedUser = identityUser?.id && identityUser.email ? { id: identityUser.id, email: identityUser.email } : null;
  if (!authenticatedUser) {
    const authorization = request.headers.get("authorization");
    const token = authorization?.startsWith("Bearer ") ? authorization.slice(7) : null;
    const secret = process.env.JWT_SECRET;
    if (token && secret) {
      try {
        const { payload } = await jwtVerify(token, new TextEncoder().encode(secret), {
          algorithms: ["HS256"]
        });
        if (typeof payload.sub === "string" && typeof payload.email === "string") {
          authenticatedUser = { id: payload.sub, email: payload.email };
        }
      } catch {
        throw new AuthenticationError("Unauthorized");
      }
    }
  }
  if (!authenticatedUser) throw new AuthenticationError("Unauthorized");
  await db.insert(users).values(authenticatedUser).onConflictDoUpdate({
    target: users.id,
    set: { email: authenticatedUser.email }
  });
  return authenticatedUser;
}

// netlify/functions/_shared/http.mts
var json = (body, init = {}) => Response.json(body, init);
function errorResponse(error) {
  if (error instanceof AuthenticationError) return json({ error: error.message }, { status: 401 });
  const message = error instanceof Error ? error.message : "Unexpected server error";
  console.error(error);
  return json({ error: message }, { status: 500 });
}
async function readJson(request) {
  return request.json();
}

// netlify/functions/data.mts
var tables = /* @__PURE__ */ new Set([
  "clinics",
  "user_clinics",
  "patients",
  "providers",
  "provider_availability",
  "appointments",
  "procedures",
  "visits",
  "visit_procedures",
  "invoices",
  "payments",
  "audit_logs",
  "subscriptions",
  "notifications",
  "backups",
  "appointment_reminders",
  "subscription_invoices",
  "users"
]);
var directClinicTables = /* @__PURE__ */ new Set([
  "patients",
  "providers",
  "appointments",
  "procedures",
  "visits",
  "invoices",
  "payments",
  "audit_logs",
  "subscriptions",
  "notifications",
  "backups",
  "appointment_reminders",
  "subscription_invoices",
  "user_clinics"
]);
var privilegedWrites = {
  clinics: ["owner"],
  user_clinics: ["owner"],
  providers: ["owner", "admin"],
  provider_availability: ["owner", "admin"],
  procedures: ["owner", "admin"],
  backups: ["owner", "admin"]
};
var identifier = (value) => {
  if (!/^[a-z_][a-z0-9_]*$/.test(value)) throw new Error(`Invalid identifier: ${value}`);
  return `"${value}"`;
};
function accessPredicate(table, userPlaceholder) {
  if (table === "clinics") return `id IN (SELECT clinic_id FROM user_clinics WHERE user_id = ${userPlaceholder})`;
  if (table === "users") return `id = ${userPlaceholder} OR id IN (
    SELECT peer.user_id FROM user_clinics peer
    JOIN user_clinics mine ON mine.clinic_id = peer.clinic_id
    WHERE mine.user_id = ${userPlaceholder}
  )`;
  if (table === "notifications") return `user_id = ${userPlaceholder}`;
  if (table === "provider_availability") return `provider_id IN (
    SELECT p.id FROM providers p JOIN user_clinics uc ON uc.clinic_id = p.clinic_id WHERE uc.user_id = ${userPlaceholder}
  )`;
  if (table === "visit_procedures") return `visit_id IN (
    SELECT v.id FROM visits v JOIN user_clinics uc ON uc.clinic_id = v.clinic_id WHERE uc.user_id = ${userPlaceholder}
  )`;
  if (directClinicTables.has(table)) return `clinic_id IN (SELECT clinic_id FROM user_clinics WHERE user_id = ${userPlaceholder})`;
  throw new Error(`No access policy configured for ${table}`);
}
function buildWhere(table, userId, filters = [], or, orForeignTable) {
  const values = [userId];
  const clauses = [accessPredicate(table, "$1")];
  for (const filter of filters) {
    if (filter.column.includes(".")) {
      if (table === "appointment_reminders" && filter.column === "appointments.status" && filter.operator === "neq") {
        values.push(filter.value);
        clauses.push(`appointment_id IN (SELECT id FROM appointments WHERE status <> $${values.length})`);
        continue;
      }
      throw new Error(`Unsupported related filter: ${filter.column}`);
    }
    const column = identifier(filter.column);
    if (filter.operator === "in") {
      const list = Array.isArray(filter.value) ? filter.value : [];
      if (!list.length) clauses.push("false");
      else {
        const placeholders = list.map((item) => {
          values.push(item);
          return `$${values.length}`;
        });
        clauses.push(`${column} IN (${placeholders.join(", ")})`);
      }
      continue;
    }
    if (filter.operator === "is") {
      clauses.push(filter.value === null ? `${column} IS NULL` : `${column} IS NOT NULL`);
      continue;
    }
    values.push(filter.value);
    const operators = { eq: "=", neq: "<>", gte: ">=", lte: "<=" };
    clauses.push(`${column} ${operators[filter.operator]} $${values.length}`);
  }
  if (or) {
    if (orForeignTable === "patients" && (table === "visits" || table === "appointments")) {
      const nested = or.split(",").map((condition) => {
        const [, column, operator, ...rawValue] = condition.split(".");
        if (!column || operator !== "ilike") throw new Error("Unsupported related OR filter");
        values.push(rawValue.join(".").replaceAll("*", "%"));
        return `${identifier(column)} ILIKE $${values.length}`;
      });
      clauses.push(`patient_id IN (SELECT id FROM patients WHERE ${nested.join(" OR ")})`);
      return { sql: clauses.join(" AND "), values };
    }
    const orClauses = or.split(",").map((condition) => {
      const [column, operator, ...rawValue] = condition.split(".");
      if (!column || operator !== "ilike") throw new Error("Unsupported OR filter");
      values.push(rawValue.join(".").replaceAll("*", "%"));
      return `${identifier(column)} ILIKE $${values.length}`;
    });
    clauses.push(`(${orClauses.join(" OR ")})`);
  }
  return { sql: clauses.join(" AND "), values };
}
async function hydrate(table, rows, select = "") {
  if (!rows.length || !select) return rows;
  const database = getDatabase();
  const attach = async (relation, foreignKey, sourceTable) => {
    if (!select.includes(relation)) return;
    const ids = [...new Set(rows.map((row) => row[foreignKey]).filter(Boolean))];
    if (!ids.length) return;
    const result = await database.pool.query(`SELECT * FROM ${identifier(sourceTable)} WHERE id = ANY($1::uuid[])`, [ids]);
    const byId = new Map(result.rows.map((row) => [row.id, row]));
    rows.forEach((row) => {
      row[relation] = byId.get(row[foreignKey]) ?? null;
    });
  };
  if (table === "user_clinics") await attach("clinics", "clinic_id", "clinics");
  if (table === "visits") {
    await attach("patients", "patient_id", "patients");
    await attach("providers", "provider_id", "providers");
    await attach("appointments", "appointment_id", "appointments");
  }
  if (table === "appointments") {
    await attach("patients", "patient_id", "patients");
    await attach("providers", "provider_id", "providers");
  }
  if (table === "visit_procedures") await attach("procedures", "procedure_id", "procedures");
  if (table === "appointment_reminders") {
    await attach("appointments", "appointment_id", "appointments");
    const appointments2 = rows.map((row) => row.appointments).filter(Boolean);
    const patientIds = [...new Set(appointments2.map((row) => row.patient_id).filter(Boolean))];
    if (patientIds.length) {
      const result = await database.pool.query("SELECT * FROM patients WHERE id = ANY($1::uuid[])", [patientIds]);
      const byId = new Map(result.rows.map((row) => [row.id, row]));
      appointments2.forEach((row) => {
        row.patients = byId.get(row.patient_id) ?? null;
      });
    }
    const providerIds = [...new Set(appointments2.map((row) => row.provider_id).filter(Boolean))];
    if (providerIds.length) {
      const result = await database.pool.query("SELECT * FROM providers WHERE id = ANY($1::uuid[])", [providerIds]);
      const byId = new Map(result.rows.map((row) => [row.id, row]));
      appointments2.forEach((row) => {
        row.providers = byId.get(row.provider_id) ?? null;
      });
    }
    const clinicIds = [...new Set(rows.map((row) => row.clinic_id).filter(Boolean))];
    if (clinicIds.length) {
      const result = await database.pool.query("SELECT * FROM clinics WHERE id = ANY($1::uuid[])", [clinicIds]);
      const byId = new Map(result.rows.map((row) => [row.id, row]));
      appointments2.forEach((row, index2) => {
        row.clinics = byId.get(rows[index2]?.clinic_id) ?? null;
      });
    }
  }
  if (table === "invoices") {
    await attach("visits", "visit_id", "visits");
    const visits2 = rows.map((row) => row.visits).filter(Boolean);
    const patientIds = [...new Set(visits2.map((row) => row.patient_id).filter(Boolean))];
    if (patientIds.length) {
      const result = await database.pool.query("SELECT * FROM patients WHERE id = ANY($1::uuid[])", [patientIds]);
      const byId = new Map(result.rows.map((row) => [row.id, row]));
      visits2.forEach((row) => {
        row.patients = byId.get(row.patient_id) ?? null;
      });
    }
  }
  return rows;
}
async function assertInsertAccess(table, userId, records) {
  const database = getDatabase();
  if (table === "users") throw new Error("Users are synchronized from authentication only");
  if (table === "clinics") throw new Error("Use the clinic onboarding endpoint");
  for (const record of records) {
    let clinicId = record.clinic_id;
    if (!clinicId && table === "provider_availability") {
      const result2 = await database.pool.query("SELECT clinic_id FROM providers WHERE id = $1", [record.provider_id]);
      clinicId = result2.rows[0]?.clinic_id;
    }
    if (!clinicId && table === "visit_procedures") {
      const result2 = await database.pool.query("SELECT clinic_id FROM visits WHERE id = $1", [record.visit_id]);
      clinicId = result2.rows[0]?.clinic_id;
    }
    const result = await database.pool.query(
      "SELECT role FROM user_clinics WHERE user_id = $1 AND clinic_id = $2",
      [userId, clinicId]
    );
    if (!result.rowCount) throw new Error("Forbidden");
    const allowedRoles = privilegedWrites[table];
    if (allowedRoles && !allowedRoles.includes(result.rows[0].role)) throw new Error("Forbidden");
    if (table === "notifications" && record.user_id) {
      const target = await database.pool.query(
        "SELECT 1 FROM user_clinics WHERE user_id = $1 AND clinic_id = $2",
        [record.user_id, clinicId]
      );
      if (!target.rowCount) throw new Error("Notification recipient is not a clinic member");
    }
    if (table === "audit_logs" && record.user_id !== userId) throw new Error("Invalid audit user");
  }
}
async function assertMutationRole(table, userId, whereSql, values, filters = []) {
  const roles = privilegedWrites[table];
  if (!roles) return;
  const database = getDatabase();
  let clinicQuery;
  if (table === "clinics") clinicQuery = `SELECT id AS clinic_id FROM clinics WHERE ${whereSql}`;
  else if (table === "provider_availability") {
    const idFilter = filters.find((filter) => filter.column === "id" && filter.operator === "eq");
    const providerFilter = filters.find((filter) => filter.column === "provider_id" && filter.operator === "eq");
    if (idFilter) {
      clinicQuery = "SELECT p.clinic_id FROM provider_availability pa JOIN providers p ON p.id = pa.provider_id WHERE pa.id = $1";
      values = [idFilter.value];
    } else if (providerFilter) {
      clinicQuery = "SELECT clinic_id FROM providers WHERE id = $1";
      values = [providerFilter.value];
    } else throw new Error("Provider availability mutation requires an id filter");
  } else clinicQuery = `SELECT DISTINCT clinic_id FROM ${identifier(table)} WHERE ${whereSql}`;
  const clinics2 = await database.pool.query(clinicQuery, values);
  for (const row of clinics2.rows) {
    const membership = await database.pool.query("SELECT role FROM user_clinics WHERE user_id = $1 AND clinic_id = $2", [userId, row.clinic_id]);
    if (!membership.rows[0] || !roles.includes(membership.rows[0].role)) throw new Error("Forbidden");
  }
}
var data_default = async (request, _context) => {
  try {
    if (request.method !== "POST") return json({ error: "Method not allowed" }, { status: 405 });
    const user = await getCurrentUser(request);
    const input = await readJson(request);
    if (!tables.has(input.table)) return json({ error: "Unknown table" }, { status: 400 });
    const database = getDatabase();
    const table = identifier(input.table);
    const where = buildWhere(input.table, user.id, input.filters, input.or, input.orForeignTable);
    if (input.operation === "select") {
      const countResult = input.count === "exact" ? await database.pool.query(`SELECT count(*)::int AS count FROM ${table} WHERE ${where.sql}`, where.values) : null;
      if (input.head) return json({ data: null, error: null, count: countResult?.rows[0]?.count ?? null });
      let query = `SELECT * FROM ${table} WHERE ${where.sql}`;
      if (input.order?.length) query += ` ORDER BY ${input.order.map((item) => `${identifier(item.column)} ${item.ascending ? "ASC" : "DESC"}`).join(", ")}`;
      if (input.range) query += ` LIMIT ${Math.max(0, input.range[1] - input.range[0] + 1)} OFFSET ${Math.max(0, input.range[0])}`;
      else if (input.limit) query += ` LIMIT ${Math.max(0, input.limit)}`;
      const result2 = await database.pool.query(query, where.values);
      const rows = await hydrate(input.table, result2.rows, input.select);
      const data = input.single || input.maybeSingle ? rows[0] ?? null : rows;
      return json({ data, error: null, count: countResult?.rows[0]?.count ?? null });
    }
    if (input.operation === "insert" || input.operation === "upsert") {
      const records = Array.isArray(input.values) ? input.values : [input.values ?? {}];
      await assertInsertAccess(input.table, user.id, records);
      const columns = [...new Set(records.flatMap((record) => Object.keys(record)))];
      columns.forEach(identifier);
      const values = [];
      const rowsSql = records.map((record) => `(${columns.map((column) => {
        values.push(record[column] ?? null);
        return `$${values.length}`;
      }).join(", ")})`).join(", ");
      let query = `INSERT INTO ${table} (${columns.map(identifier).join(", ")}) VALUES ${rowsSql}`;
      if (input.operation === "upsert") {
        const conflictColumns = (input.onConflict || "id").split(",").map((column) => identifier(column.trim()));
        const updateColumns = columns.filter((column) => !conflictColumns.includes(identifier(column)));
        query += ` ON CONFLICT (${conflictColumns.join(", ")}) DO UPDATE SET ${updateColumns.map((column) => `${identifier(column)} = EXCLUDED.${identifier(column)}`).join(", ")}`;
      }
      query += " RETURNING *";
      const result2 = await database.pool.query(query, values);
      const data = input.single || input.maybeSingle ? result2.rows[0] ?? null : result2.rows;
      return json({ data, error: null, count: null });
    }
    if (input.operation === "update") {
      await assertMutationRole(input.table, user.id, where.sql, where.values, input.filters);
      const valuesToSet = input.values && !Array.isArray(input.values) ? input.values : {};
      const queryValues = [...where.values];
      const assignments = Object.entries(valuesToSet).map(([column, value]) => {
        queryValues.push(value);
        return `${identifier(column)} = $${queryValues.length}`;
      });
      const result2 = await database.pool.query(
        `UPDATE ${table} SET ${assignments.join(", ")} WHERE ${where.sql} RETURNING *`,
        queryValues
      );
      const data = input.single || input.maybeSingle ? result2.rows[0] ?? null : result2.rows;
      return json({ data, error: null, count: null });
    }
    await assertMutationRole(input.table, user.id, where.sql, where.values, input.filters);
    if (input.table === "patients") {
      const clinics2 = await database.pool.query(`SELECT DISTINCT clinic_id FROM patients WHERE ${where.sql}`, where.values);
      for (const row of clinics2.rows) {
        const membership = await database.pool.query("SELECT role FROM user_clinics WHERE user_id = $1 AND clinic_id = $2", [user.id, row.clinic_id]);
        if (!["owner", "admin"].includes(membership.rows[0]?.role)) throw new Error("Forbidden");
      }
    }
    const result = await database.pool.query(`DELETE FROM ${table} WHERE ${where.sql} RETURNING *`, where.values);
    return json({ data: input.single ? result.rows[0] ?? null : result.rows, error: null, count: null });
  } catch (error) {
    return errorResponse(error);
  }
};
var config = { path: "/api/data" };
export {
  config,
  data_default as default
};
