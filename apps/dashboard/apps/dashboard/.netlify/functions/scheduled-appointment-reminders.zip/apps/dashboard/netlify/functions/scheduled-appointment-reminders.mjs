
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// netlify/functions/process-appointment-reminders.mts
import { getDatabase } from "@netlify/database";

// netlify/functions/_shared/auth.mts
import { getUser } from "@netlify/identity";
import { jwtVerify } from "jose";

// db/index.ts
import { drizzle } from "drizzle-orm/netlify-db";

// db/schema.ts
var schema_exports = {};
__export(schema_exports, {
  appointmentReminders: () => appointmentReminders,
  appointments: () => appointments,
  auditLogs: () => auditLogs,
  backups: () => backups,
  clinics: () => clinics,
  invoices: () => invoices,
  notifications: () => notifications,
  patients: () => patients,
  payments: () => payments,
  procedures: () => procedures,
  providerAvailability: () => providerAvailability,
  providers: () => providers,
  subscriptionInvoices: () => subscriptionInvoices,
  subscriptions: () => subscriptions,
  userClinics: () => userClinics,
  users: () => users,
  visitProcedures: () => visitProcedures,
  visits: () => visits
});
import {
  bigint,
  boolean,
  check,
  date,
  index,
  integer,
  jsonb,
  numeric,
  pgTable,
  text,
  time,
  timestamp,
  unique,
  uuid
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
var timestamps = {
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow()
};
var users = pgTable("users", {
  id: uuid("id").primaryKey(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
});
var clinics = pgTable("clinics", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  address: text("address"),
  phone: text("phone"),
  email: text("email"),
  plan: text("plan").notNull().default("starter"),
  subscriptionStatus: text("subscription_status").notNull().default("inactive"),
  currencyCode: text("currency_code").default("PHP"),
  currencySymbol: text("currency_symbol").default("\u20B1"),
  ...timestamps
});
var userClinics = pgTable("user_clinics", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  role: text("role").notNull().default("staff"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (table) => [
  unique("user_clinics_user_id_clinic_id_key").on(table.userId, table.clinicId),
  check("user_clinics_role_check", sql`${table.role} in ('owner', 'admin', 'staff')`),
  index("idx_user_clinics_user_id").on(table.userId),
  index("idx_user_clinics_clinic_id").on(table.clinicId)
]);
var patients = pgTable("patients", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email"),
  phone: text("phone"),
  dateOfBirth: date("date_of_birth"),
  gender: text("gender"),
  address: text("address"),
  medicalNotes: text("medical_notes"),
  ...timestamps
}, (table) => [
  check("patients_gender_check", sql`${table.gender} is null or ${table.gender} in ('male', 'female', 'other')`),
  index("idx_patients_clinic_id").on(table.clinicId),
  index("idx_patients_name").on(table.lastName, table.firstName)
]);
var providers = pgTable("providers", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
  name: text("name").notNull(),
  specialization: text("specialization"),
  ...timestamps
}, (table) => [
  index("idx_providers_clinic_id").on(table.clinicId),
  index("idx_providers_user_id").on(table.userId)
]);
var providerAvailability = pgTable("provider_availability", {
  id: uuid("id").primaryKey().defaultRandom(),
  providerId: uuid("provider_id").notNull().references(() => providers.id, { onDelete: "cascade" }),
  dayOfWeek: integer("day_of_week").notNull(),
  startTime: time("start_time").notNull(),
  endTime: time("end_time").notNull(),
  ...timestamps
}, (table) => [
  check("provider_availability_day_check", sql`${table.dayOfWeek} between 0 and 6`),
  unique("idx_provider_day_time").on(table.providerId, table.dayOfWeek, table.startTime),
  index("idx_provider_availability_provider_id").on(table.providerId)
]);
var appointments = pgTable("appointments", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  patientId: uuid("patient_id").notNull().references(() => patients.id, { onDelete: "cascade" }),
  providerId: uuid("provider_id").references(() => providers.id, { onDelete: "set null" }),
  startTime: timestamp("start_time", { withTimezone: true }).notNull(),
  endTime: timestamp("end_time", { withTimezone: true }).notNull(),
  status: text("status").default("scheduled"),
  notes: text("notes"),
  ...timestamps
}, (table) => [
  check("appointments_status_check", sql`${table.status} in ('scheduled', 'confirmed', 'completed', 'cancelled')`),
  index("idx_appointments_clinic").on(table.clinicId),
  index("idx_appointments_clinic_id").on(table.clinicId),
  index("idx_appointments_patient_id").on(table.patientId),
  index("idx_appointments_provider_id").on(table.providerId),
  index("idx_provider_time").on(table.providerId, table.startTime, table.endTime),
  index("idx_appointments_provider_day").on(table.providerId, table.startTime),
  index("idx_appointments_clinic_start_time").on(table.clinicId, table.startTime)
]);
var procedures = pgTable("procedures", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  description: text("description").default(""),
  baseCost: numeric("base_cost", { precision: 10, scale: 2 }).notNull().default("0"),
  ...timestamps
}, (table) => [index("idx_procedures_clinic_id").on(table.clinicId)]);
var visits = pgTable("visits", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  appointmentId: uuid("appointment_id").references(() => appointments.id, { onDelete: "set null" }),
  patientId: uuid("patient_id").notNull().references(() => patients.id, { onDelete: "cascade" }),
  providerId: uuid("provider_id").notNull().references(() => providers.id, { onDelete: "restrict" }),
  status: text("status").notNull().default("scheduled"),
  chiefComplaint: text("chief_complaint").default(""),
  diagnosis: text("diagnosis").default(""),
  notes: text("notes").default(""),
  visitDate: timestamp("visit_date", { withTimezone: true }).notNull().defaultNow(),
  ...timestamps
}, (table) => [
  check("valid_visit_status", sql`${table.status} in ('scheduled', 'in_progress', 'completed', 'cancelled')`),
  unique("unique_visit_per_appointment").on(table.appointmentId),
  index("idx_visits_clinic_id").on(table.clinicId),
  index("idx_visits_patient_id").on(table.patientId),
  index("idx_visits_appointment_id").on(table.appointmentId),
  index("idx_visits_clinic_date").on(table.clinicId, table.visitDate.desc())
]);
var visitProcedures = pgTable("visit_procedures", {
  id: uuid("id").primaryKey().defaultRandom(),
  visitId: uuid("visit_id").notNull().references(() => visits.id, { onDelete: "cascade" }),
  procedureId: uuid("procedure_id").notNull().references(() => procedures.id, { onDelete: "restrict" }),
  quantity: integer("quantity").notNull().default(1),
  price: numeric("price", { precision: 10, scale: 2 }).notNull().default("0"),
  notes: text("notes").default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (table) => [
  check("positive_quantity", sql`${table.quantity} > 0`),
  check("non_negative_price", sql`${table.price} >= 0`),
  unique("unique_visit_procedure").on(table.visitId, table.procedureId),
  index("idx_visit_procedures_visit_id").on(table.visitId),
  index("idx_visit_procedures_procedure_id").on(table.procedureId)
]);
var invoices = pgTable("invoices", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  visitId: uuid("visit_id").notNull().references(() => visits.id, { onDelete: "cascade" }),
  status: text("status").notNull().default("unpaid"),
  totalAmount: numeric("total_amount", { precision: 10, scale: 2 }).notNull().default("0"),
  amountPaid: numeric("amount_paid", { precision: 10, scale: 2 }).notNull().default("0"),
  ...timestamps
}, (table) => [
  check("invoices_status_check", sql`${table.status} in ('unpaid', 'partial', 'paid', 'void')`),
  unique("invoices_visit_unique").on(table.visitId),
  index("idx_invoices_clinic_id").on(table.clinicId),
  index("idx_invoices_clinic").on(table.clinicId),
  index("idx_invoices_visit").on(table.visitId),
  index("idx_invoices_status").on(table.status)
]);
var payments = pgTable("payments", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  invoiceId: uuid("invoice_id").notNull().references(() => invoices.id, { onDelete: "cascade" }),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  method: text("method").notNull(),
  notes: text("notes").default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (table) => [
  check("payments_method_check", sql`${table.method} in ('cash', 'card', 'bank_transfer', 'other')`),
  index("idx_payments_clinic_id").on(table.clinicId),
  index("idx_payments_invoice_id").on(table.invoiceId),
  index("idx_payments_invoice").on(table.invoiceId)
]);
var auditLogs = pgTable("audit_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  action: text("action").notNull(),
  entityType: text("entity_type").notNull(),
  entityId: uuid("entity_id").notNull(),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (table) => [
  index("idx_audit_logs_clinic_id").on(table.clinicId),
  index("idx_audit_logs_created_at").on(table.createdAt.desc()),
  index("idx_audit_logs_clinic_created").on(table.clinicId, table.createdAt.desc()),
  index("idx_audit_logs_entity").on(table.entityType, table.entityId),
  index("idx_audit_logs_user_id").on(table.userId)
]);
var subscriptions = pgTable("subscriptions", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  stripeCustomerId: text("stripe_customer_id").notNull().unique(),
  stripeSubscriptionId: text("stripe_subscription_id").unique(),
  plan: text("plan").notNull().default("starter"),
  status: text("status").notNull().default("incomplete"),
  currentPeriodEnd: timestamp("current_period_end", { withTimezone: true }),
  ...timestamps
}, (table) => [
  index("idx_subscriptions_clinic_id").on(table.clinicId),
  index("idx_subscriptions_stripe_customer_id").on(table.stripeCustomerId),
  index("idx_subscriptions_stripe_subscription_id").on(table.stripeSubscriptionId)
]);
var notifications = pgTable("notifications", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  type: text("type").notNull(),
  message: text("message").notNull(),
  read: boolean("read").notNull().default(false),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (table) => [
  index("idx_notifications_user_id").on(table.userId),
  index("idx_notifications_clinic_id").on(table.clinicId),
  index("idx_notifications_read").on(table.read),
  index("idx_notifications_created_at").on(table.createdAt.desc()),
  index("idx_notifications_user_read").on(table.userId, table.read)
]);
var backups = pgTable("backups", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").references(() => clinics.id, { onDelete: "cascade" }),
  backupTime: timestamp("backup_time", { withTimezone: true }).notNull().defaultNow(),
  backupStatus: text("backup_status").notNull().default("pending"),
  storageUrl: text("storage_url"),
  backupSize: bigint("backup_size", { mode: "number" }).default(0),
  backupType: text("backup_type").notNull().default("full"),
  errorMessage: text("error_message"),
  ...timestamps
}, (table) => [
  index("idx_backups_clinic_id").on(table.clinicId),
  index("idx_backups_backup_time").on(table.backupTime.desc()),
  index("idx_backups_status").on(table.backupStatus)
]);
var appointmentReminders = pgTable("appointment_reminders", {
  id: uuid("id").primaryKey().defaultRandom(),
  appointmentId: uuid("appointment_id").notNull().references(() => appointments.id, { onDelete: "cascade" }),
  clinicId: uuid("clinic_id").notNull().references(() => clinics.id, { onDelete: "cascade" }),
  reminderTime: timestamp("reminder_time", { withTimezone: true }).notNull(),
  sent: boolean("sent").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow()
}, (table) => [
  index("idx_appointment_reminders_pending").on(table.clinicId, table.sent, table.reminderTime).where(sql`${table.sent} = false`),
  index("idx_appointment_reminders_appointment_id").on(table.appointmentId)
]);
var subscriptionInvoices = pgTable("subscription_invoices", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: uuid("clinic_id").references(() => clinics.id, { onDelete: "cascade" }),
  stripeInvoiceId: text("stripe_invoice_id").notNull().unique(),
  stripeSubscriptionId: text("stripe_subscription_id"),
  amountDue: numeric("amount_due", { precision: 10, scale: 2 }).notNull().default("0"),
  amountPaid: numeric("amount_paid", { precision: 10, scale: 2 }).notNull().default("0"),
  currency: text("currency").notNull().default("usd"),
  status: text("status").notNull().default("open"),
  invoicePdfUrl: text("invoice_pdf_url"),
  paidAt: timestamp("paid_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow()
}, (table) => [
  index("idx_subscription_invoices_clinic_id").on(table.clinicId),
  index("idx_subscription_invoices_stripe_invoice_id").on(table.stripeInvoiceId)
]);

// db/index.ts
var db = drizzle({ schema: schema_exports });

// netlify/functions/process-appointment-reminders.mts
async function processAppointmentReminders() {
  const database = getDatabase();
  const result = await database.pool.query(
    `SELECT ar.id, a.start_time, p.first_name, p.last_name, p.email AS patient_email,
            pr.name AS provider_name, c.name AS clinic_name, c.email AS clinic_email
     FROM appointment_reminders ar
     JOIN appointments a ON a.id = ar.appointment_id
     JOIN patients p ON p.id = a.patient_id
     LEFT JOIN providers pr ON pr.id = a.provider_id
     JOIN clinics c ON c.id = ar.clinic_id
     WHERE ar.sent = false AND ar.reminder_time <= now() AND a.status <> 'cancelled'
     ORDER BY ar.reminder_time LIMIT 100`
  );
  const resendKey = process.env.RESEND_API_KEY;
  let sent = 0;
  let skipped = 0;
  for (const reminder of result.rows) {
    if (!reminder.patient_email || !resendKey) {
      skipped += 1;
      continue;
    }
    const appointmentDate = new Date(reminder.start_time);
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${resendKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: reminder.clinic_email ? `${reminder.clinic_name} <${reminder.clinic_email}>` : `${reminder.clinic_name} <onboarding@resend.dev>`,
        to: [reminder.patient_email],
        subject: `Appointment reminder from ${reminder.clinic_name}`,
        html: `<p>Hello ${reminder.first_name} ${reminder.last_name},</p><p>This is a reminder for your appointment on <strong>${appointmentDate.toLocaleString("en-US")}</strong> with ${reminder.provider_name || "your provider"}.</p>`
      })
    });
    if (response.ok) {
      await database.pool.query("UPDATE appointment_reminders SET sent = true WHERE id = $1", [reminder.id]);
      sent += 1;
    } else skipped += 1;
  }
  return { processed: result.rowCount, sent, skipped };
}

// netlify/functions/scheduled-appointment-reminders.mts
var scheduled_appointment_reminders_default = async () => Response.json(await processAppointmentReminders());
var config = { schedule: "*/15 * * * *" };
export {
  config,
  scheduled_appointment_reminders_default as default
};
